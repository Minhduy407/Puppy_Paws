function toggleList() {
    var list = document.getElementById("list");
    list.style.display = (list.style.display === 'none') ? 'block' : 'none';
}

